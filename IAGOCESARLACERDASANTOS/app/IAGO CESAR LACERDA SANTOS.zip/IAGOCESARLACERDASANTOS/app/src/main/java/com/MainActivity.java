// MainActivity.java
package com; // Substitua com o nome do seu pacote

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.iagocesarlacerdasantos.R;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    private TextView nameText, surnameText, enrollmentText, finalMessage;
    private GridLayout keyGrid;
    private ArrayList<Button> keyButtons = new ArrayList<>();
    private String name = "*";
    private String surname = "*";
    private String enrollment = "*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os componentes de interface
        nameText = findViewById(R.id.nameText);
        surnameText = findViewById(R.id.surnameText);
        enrollmentText = findViewById(R.id.enrollmentText);
        finalMessage = findViewById(R.id.finalMessage);
        keyGrid = findViewById(R.id.keyGrid);

        // Inicializa os botões e configurações
        initializeKeyButtons();
        setupButtons();
    }

    // Método para inicializar os botões de teclas no GridLayout
    private void initializeKeyButtons() {
        // Exemplo de teclas para preencher o GridLayout
        String[] keys = {"A", "B", "C", "1", "2", "3", "D", "E", "F", "4", "5", "6", "G", "H", "I", "7", "8", "9", "J", "K", "L", "0", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V"};

        for (String key : keys) {
            Button button = new Button(this);
            button.setText(key);
            button.setOnClickListener(this::onKeyClick);
            keyButtons.add(button);
            keyGrid.addView(button);
        }
    }

    // Método para configurar os botões de embaralhar e resetar
    private void setupButtons() {
        Button shuffleButton = findViewById(R.id.shuffleButton);
        Button resetButton = findViewById(R.id.resetButton);

        shuffleButton.setOnClickListener(v -> shuffleKeys());
        resetButton.setOnClickListener(v -> resetFields());
    }

    // Método chamado quando um botão de tecla é clicado
    private void onKeyClick(View v) {
        Button button = (Button) v;
        String value = button.getText().toString();

        // Lógica para preencher os campos (Nome, Sobrenome e Matrícula)
        if (name.contains("*")) {
            name = name.replaceFirst("\\*", value);
            nameText.setText("Nome: " + name);
        } else if (surname.contains("*")) {
            surname = surname.replaceFirst("\\*", value);
            surnameText.setText("Sobrenome: " + surname);
        } else if (enrollment.contains("*")) {
            enrollment = enrollment.replaceFirst("\\*", value);
            enrollmentText.setText("Matrícula: " + enrollment);
        }

        // Verificação se todos os campos foram preenchidos
        if (!name.contains("") && !surname.contains("") && !enrollment.contains("*")) {
            finalMessage.setText("Parabéns! Você completou");
        }
    }

    // Método para embaralhar os botões no GridLayout
    private void shuffleKeys() {
        Collections.shuffle(keyButtons);
        keyGrid.removeAllViews();
        for (Button button : keyButtons) {
            keyGrid.addView(button);
        }
    }

    // Método para resetar os campos para o estado original
    private void resetFields() {
        name = "*";
        surname = "*";
        enrollment = "*";
        nameText.setText("Nome: " + name);
        surnameText.setText("Sobrenome: " + surname);
        enrollmentText.setText("Matrícula: " + enrollment);
        finalMessage.setText("");
    }
}
